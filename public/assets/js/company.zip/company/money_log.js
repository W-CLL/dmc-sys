define(['jquery', 'bootstrap', 'company', 'table', 'form'], function ($, undefined, Company, Table, Form) {

    var Controller = {
        index: function () {
            Controller.api.bindevent();
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'money_log/index' + location.search,
                    table: 'money_log',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                // ... 其他配置 ...
                search: false, // 禁用默认搜索
                commonSearch: false, // 启用普通表单搜索
                searchFormVisible: true, // 控制搜索栏是否显示在页面上
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                fixedColumns: true,
                fixedRightNumber: 1,
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id'),visible: false},
                        {field: 'money', title: "金额"},
                        {field: 'type', title: "类型", formatter: function(value,row,index) {
                            if (row.type == 1){
                                return "平台赠送"
                            }else if (row.type == 2){
                                return "平台扣款"
                            }else if (row.type == 3){
                                return "充值"
                            }else if (row.type == 4){
                                return "转入"
                            }else if (row.type == 5){
                                return "转出"
                            }
                            }, operate: 'LIKE'},
                        {field: 'explain', title: "说明"},
                        {field: 'create_time', title:"时间" ,formatter: Table.api.formatter.datetime},
                        // {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate},
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});
